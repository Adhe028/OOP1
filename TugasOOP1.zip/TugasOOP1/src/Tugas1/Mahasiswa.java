/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas1;

/**
 *
 * @author Toshiba
 */
public class Mahasiswa {
    
    public static void main(String[] args) {
        String nim1 = "18090088";
        String nama1 = "Ade Kurniawan";
        String Kelas1 = "4C";
       
        System.out.println("Nim : " +nim1 );
        System.out.println("Nama : " +nama1);
        System.out.println("Kelas : "+ Kelas1);
        
        System.out.println();
    }
}
